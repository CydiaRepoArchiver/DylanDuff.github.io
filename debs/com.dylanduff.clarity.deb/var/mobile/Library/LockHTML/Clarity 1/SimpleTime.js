/*!
 * SimpleTime v1.0 (http://dylanduff.github.io)
 */
 
function SimpleTime() {
    var date = new Date();
    var hr = date.getHours();
    var min = date.getMinutes();
    var sec = date.getSeconds();

    var ampm = " PM "
if (hr < 12){
ampm = " AM "
}
if (hr > 12){
hr -= 12
}
if (hr < 10){
hr = " " + hr
}
if (min < 10){
min = "0" + min
}
if (sec < 10){
sec = "0" + sec
}    

document.getElementById('clock').innerHTML = hr + ":" + min;

}




