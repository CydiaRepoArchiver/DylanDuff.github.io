/*!
 * SimpleTime v1.0 (http://dylanduff.github.io)
 */
 
function SimpleTime() {
    var date = new Date();
    var hr = date.getHours();
    var min = date.getMinutes();
    var sec = date.getSeconds();
    var ampm = " PM "
    var daynum = date.getDate();
    
if (hr < 12){
ampm = " AM "
}
if (hr > 12){
hr -= 12
}
if (hr < 10){
hr = " " + hr
}
if (min < 10){
min = "0" + min
}
if (sec < 10){
sec = "0" + sec
}    

document.getElementById('clock').innerHTML = hr + ":" + min;
document.getElementById('ampm').innerHTML = ampm;
document.getElementById('daynum').innerHTML = daynum;

var month = new Array();
month[0] = "January";
month[1] = "February";
month[2] = "March";
month[3] = "April";
month[4] = "May";
month[5] = "June";
month[6] = "July";
month[7] = "August";
month[8] = "September";
month[9] = "October";
month[10] = "November";
month[11] = "December";
var monthname = month[date.getMonth()];
document.getElementById("month").innerHTML = monthname;
}





